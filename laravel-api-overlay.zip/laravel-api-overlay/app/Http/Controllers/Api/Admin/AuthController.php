<?php
namespace App\Http\Controllers\Api\Admin;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
class AuthController extends Controller {
    public function login(Request $request) {
        $data = $request->validate(['email' => ['required', 'email'], 'password' => ['required', 'string']]);
        $user = User::where('email', $data['email'])->first();
        if (! $user || ! $user->is_admin || ! Hash::check($data['password'], $user->password)) {
            throw ValidationException::withMessages(['email' => 'Invalid credentials.']);
        }
        return response()->json(['token' => $user->createToken('dashboard', ['*'], now()->addDays(7))->plainTextToken,
            'user' => ['name' => $user->name, 'email' => $user->email]]);
    }
    public function me(Request $request) { return response()->json(['name' => $request->user()->name, 'email' => $request->user()->email]); }
    public function logout(Request $request) { $request->user()->currentAccessToken()->delete(); return response()->noContent(); }
}
